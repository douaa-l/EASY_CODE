package com.example.easycode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.easycode.Outils.Plaque;
import com.example.easycode.Outils.unTest;
import com.example.easycode.Outils.uneLecon;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TestActivity extends AppCompatActivity {
int num_niveau=0;
String id_user="";
String titre_cours="";
String titre_theme="";
int nbQuestions=3;
int nb=nbQuestions*2;
int total=0;
LinearLayout ll=null;
TextView question=null;
TextView numquestion=null;
ImageView imagequestion=null;
Button nextQuestion=null;
int num=1;
String id_cours;

    ArrayList<unTest> rows=new ArrayList<unTest>();
    private static String URL_REGIST="http://192.168.1.6/projet/includes/get_qst_cours.php";
    private static String URL_VERIF="http://192.168.1.6/projet/includes/evaluate_cours.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        Intent intent=getIntent();
        if(intent!=null){

            if (intent.hasExtra("num_niveau")){
                num_niveau = intent.getIntExtra("num_niveau",0);}
            if (intent.hasExtra("id_cours")){
                id_cours= (intent.getStringExtra("id_cours"));}
            if (intent.hasExtra("id_user")){
                id_user = intent.getStringExtra("id_user");
            }
            if (intent.hasExtra("titre_cours")){
                titre_cours = intent.getStringExtra("titre_cours");
            }
            if (intent.hasExtra("titre_theme")){
                titre_theme = intent.getStringExtra("titre_theme");
            }
            System.out.println("&&&&&&&&&&&&&&&&&&&&&&"+num_niveau+" "+id_user+" "+titre_cours+" "+titre_theme+" "+nbQuestions+"&&&&&&");


        }
        nextQuestion=findViewById(R.id.nextQuestion);
        nextQuestion.setOnClickListener(suivant);
        ll=findViewById(R.id.llchoix);
        imagequestion=findViewById(R.id.imagequestion);
        numquestion=findViewById(R.id.numquestion);
        question=findViewById(R.id.question);


        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_REGIST, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

              try {

                    JSONArray array = new JSONArray(response);

                  for(int i=0;i<(array.length());i++){
                      rows.add(new unTest(array.getJSONObject(i)));

                  }

                  int imgid=getResources().getIdentifier(rows.get(0).getImage()+"g","drawable","com.example.easycode");
                  imagequestion.setImageDrawable(getResources().getDrawable(imgid));
                  numquestion.setText("Question 1");
                  question.setText(rows.get(0).getQuestion());
                  String []table=rows.get(0).aleaChoix();
                  int max=2;
                  if(rows.get(0).getType_quiz().equals("multi"))max=3;
                  for (int i=0;i<max;i++){
                      System.out.println("&&&&&&&&&&&&&&&&&"+table[i]);
                      Button b=new Button(TestActivity.this);
                      b.setText(table[i]);
                      b.setTextSize(18);
                      b.setTextColor(getResources().getColor(R.color.blanc));
                      b.setPadding(10,40,10,40);

                      LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                              LinearLayout.LayoutParams.MATCH_PARENT,
                              LinearLayout.LayoutParams.WRAP_CONTENT
                      );
                      params.setMargins(0, 10, 0, 10);
                      b.setLayoutParams(params);
                      b.setOnClickListener(verifierReponse);
                      b.setTag(0);
                      ll.addView(b);

                  }



                } catch (JSONException e) {
                    e.printStackTrace();


                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {




                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String>params=new HashMap<>();
                params.put("titre_cours", titre_cours);
                params.put("titre_theme", titre_theme);
                params.put("num_niveau", String.valueOf(num_niveau));
                params.put("nbQstParType", String.valueOf(nbQuestions));
                params.put("id_user", id_user);
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(TestActivity.this);
        requestQueue.add(stringRequest);
    }

    public View.OnClickListener verifierReponse=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Button b=(Button)v;
            int i=(int)v.getTag();
            if((b.getText()).equals(rows.get(i).getReponseJuste())){
                b.setBackgroundColor(getResources().getColor(R.color.vert));
                total++;
            }else {
                b.setBackgroundColor(getResources().getColor(R.color.colorAccent));

            }


        }
    };

    public View.OnClickListener suivant=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
nb--;
if(nb!=0){
            ll.removeAllViewsInLayout();
            int imgid=getResources().getIdentifier(rows.get(num).getImage()+"g","drawable","com.example.easycode");
            imagequestion.setImageDrawable(getResources().getDrawable(imgid));

            question.setText(rows.get(num).getQuestion());
            String []table=rows.get(num).aleaChoix();
            int max=2;
            if(rows.get(num).getType_quiz().equals("multi"))max=3;
            for (int i=0;i<max;i++){
                System.out.println("&&&&&&&&&&&&&&&&&"+table[i]);
                Button b=new Button(TestActivity.this);
                b.setText(table[i]);
                b.setTextSize(18);
                b.setTextColor(getResources().getColor(R.color.blanc));
                b.setPadding(10,40,10,40);

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
                params.setMargins(0, 10, 0, 10);
                b.setLayoutParams(params);
                b.setOnClickListener(verifierReponse);
                b.setTag(num);
                ll.addView(b);

            }
            num++;
            numquestion.setText("Question "+num);

        }else{

    StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_VERIF, new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {


                String phrase="Vous n'avez malheureusement pas réussi le test!Revisez et reesayez à nouveau!";


                String etatprochain=response;
                System.out.println("&&&&&&&&&&&&&&&&&&"+response);
                if (etatprochain.equals("unblocked")){phrase="Felicitations!vous venez de débloquer le prochain cours";}

                Toast.makeText(TestActivity.this,"Vous avez eu :"+ total+"/6 "+phrase,Toast.LENGTH_LONG).show();
                TestActivity.this.finish();



        }
    },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {




                }
            }) {
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            Map<String,String>params=new HashMap<>();
            params.put("id_cours", id_cours);
            params.put("moyenne", String.valueOf(total));

            return params;
        }

    };

    RequestQueue requestQueue = Volley.newRequestQueue(TestActivity.this);
    requestQueue.add(stringRequest);



}

        }
    };
}
