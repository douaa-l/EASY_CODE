package com.example.easycode;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.easycode.ui.HomeActivity;
import com.example.easycode.ui.NotesActivity;
import com.example.easycode.ui.ProfilActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class NiveauActivity extends AppCompatActivity {
    Button cours=null;
    Button profil=null;
    Button notes=null;

    String id_user="";

Bundle bundle=new Bundle();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_niveau);
        Intent intent= getIntent();
        if(intent!=null){


            if (intent.hasExtra("id_user")){
                id_user = intent.getStringExtra("id_user");
            }


            bundle.putString("id_user",id_user);




        }
        cours=(Button)findViewById(R.id.cours);
         profil=(Button)findViewById(R.id.profil);
        notes=(Button)findViewById(R.id.notes);



        cours.setOnClickListener(navListener);
        profil.setOnClickListener(navListener);
        notes.setOnClickListener(navListener);

        HomeActivity fragment=new HomeActivity();
        fragment.setArguments(bundle);

        getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,fragment).commit();


    }
    private View.OnClickListener navListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Fragment selectedFragment=null;
            switch (v.getId()){
                case R.id.notes:
                    selectedFragment= new NotesActivity();

                    cours.setTextColor(getResources().getColor(R.color.gristransparent));
                    profil.setTextColor(getResources().getColor(R.color.gristransparent));
                    notes.setTextColor(getResources().getColor(R.color.jaune));
                    break;
                case R.id.profil:
                    selectedFragment=new ProfilActivity();
                    cours.setTextColor(getResources().getColor(R.color.gristransparent));
                    profil.setTextColor(getResources().getColor(R.color.jaune));
                    notes.setTextColor(getResources().getColor(R.color.gristransparent));

                    break;
                case R.id.cours:
                    selectedFragment=new HomeActivity();
                    selectedFragment.setArguments(bundle);
                    cours.setTextColor(getResources().getColor(R.color.jaune));
                    profil.setTextColor(getResources().getColor(R.color.gristransparent));
                    notes.setTextColor(getResources().getColor(R.color.gristransparent));
                    break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,selectedFragment).commit();

        }
    };






}
