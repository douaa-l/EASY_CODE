package com.example.easycode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.easycode.Outils.Plaque;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MenuPlaqueActivity extends AppCompatActivity {

    Button testButton=null;
    LinearLayout ll=null;
    LinearLayout ll1=null;
    LinearLayout ll2=null;
    LinearLayout ll3=null;
    LinearLayout ll4=null;
    LinearLayout ll5=null;
    LinearLayout ll6=null;
    LinearLayout ll7=null;
    LinearLayout ll8=null;
    LinearLayout ll9=null;
    String titre_cours="";
    String theme="";
    String niveau="";
    String title="";
    int id_niveau_choisi=0;
    int id_theme_choisi=0;
    int num_niveau=0;
    String id_cours;
    String id_user="";
    TextView titrePlaques=null;
    ArrayList<Plaque> rows=new ArrayList<Plaque>();

    private static String URL_REGIST="http://192.168.1.6/projet/includes/get_plaques.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_plaque);
        Intent intent=getIntent();
        if(intent!=null){
            if (intent.hasExtra("titre_cours")){
                titre_cours= (intent.getStringExtra("titre_cours"));}

                if (intent.hasExtra("title")){
                    title= (intent.getStringExtra("title"));}
            if (intent.hasExtra("id_cours")){
                id_cours= (intent.getStringExtra("id_cours"));}

                if (intent.hasExtra("id_theme_choisi")){
                    id_theme_choisi = intent.getIntExtra("id_theme_choisi",0);
                }
                if (intent.hasExtra("theme")){
                    theme = intent.getStringExtra("theme");
                }
                if (intent.hasExtra("id_niveau_choisi")){
                    id_niveau_choisi = intent.getIntExtra("id_niveau_choisi",0);
                }
                if (intent.hasExtra("niveau")){
                    niveau = intent.getStringExtra("niveau");

                }
                if (intent.hasExtra("num_niveau")){
                    num_niveau = intent.getIntExtra("num_niveau",0);}
                if (intent.hasExtra("id_user")){
                    id_user = intent.getStringExtra("id_user");
                }
             titrePlaques=findViewById(R.id.titrePlaques);
              titrePlaques.setText(title);

            }
        testButton=findViewById(R.id.testButton);
        testButton.setOnClickListener(goToTest);
        ll= findViewById(R.id.linear);
        ll1= findViewById(R.id.linear1);
        ll2= findViewById(R.id.linear2);
        ll3=findViewById(R.id.linear3);
        ll4= findViewById(R.id.linear4);
        ll5= findViewById(R.id.linear5);
        ll6= findViewById(R.id.linear6);
        ll7= findViewById(R.id.linear7);
        ll8= findViewById(R.id.linear8);
        ll9= findViewById(R.id.linear9);


        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_REGIST, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONArray array = new JSONArray(response);

                    for(int i=0;i<(array.length());i++){
                        rows.add(new Plaque(array.getJSONObject(i)));
                        String nom_plaque=rows.get(i).getPlaque();
                        ImageView image =new ImageView(getApplicationContext());

                        image.setPadding(20,10,20,10);
                        int imgid=getResources().getIdentifier(nom_plaque,"drawable","com.example.easycode");
                        image.setImageDrawable(getResources().getDrawable(imgid));
                        image.setTag(rows.get(i));
                        image.setOnClickListener(clickPlaque);
                         if(i<3){ll.addView(image);}
                       else if(i<6){ll1.addView(image);}
                        else if(i<9){ll2.addView(image);}
                        else if(i<12){ll3.addView(image);}
                        else if(i<15){ll4.addView(image);}
                        else if(i<18){ll5.addView(image);}
                        else if(i<21){ll6.addView(image);}
                        else if(i<24){ll7.addView(image);}
                        else if(i<27){ll8.addView(image);}
                        else if(i<29){ll9.addView(image);}
                    }






                } catch (JSONException e) {
                    e.printStackTrace();


                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {




                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("titre_cours", titre_cours);

                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(MenuPlaqueActivity.this);
        requestQueue.add(stringRequest);








    }
    private View.OnClickListener clickPlaque =new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Plaque p=(Plaque)v.getTag();
            String description=p.getDiscription();
            String nom_plaque=p.getNom_plaque();
            String image=p.getPlaque()+"g";
            Intent intent=new Intent(MenuPlaqueActivity.this,SuivanteActivity.class);
            intent.putExtra("description",description);
            intent.putExtra("titre",nom_plaque);
            intent.putExtra("image",image);
            startActivity(intent);
        }
    };

    private View.OnClickListener goToTest=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent=new Intent(MenuPlaqueActivity.this,TestActivity.class);
            intent.putExtra("id_user",id_user);
            intent.putExtra("num_niveau",num_niveau);
            intent.putExtra("titre_cours",titre_cours);
            intent.putExtra("titre_theme",theme);
            intent.putExtra("id_cours",id_cours);
            startActivity(intent);
        }
    };

}
