package com.example.easycode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;

public class HTMLActivity extends AppCompatActivity {
WebView webView=null;
String titre_cours="";
String theme="";
String niveau="";
int id_theme_choisi=0;
int id_niveau_choisi=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_html);
        Intent intent= getIntent();
        if(intent!=null){

            if (intent.hasExtra("titre_cours")){
                titre_cours = intent.getStringExtra("titre_cours");
            }
            if (intent.hasExtra("id_theme_choisi")){
                id_theme_choisi = intent.getIntExtra("id_theme_choisi",0);
            }
            if (intent.hasExtra("theme")){
                theme = intent.getStringExtra("theme");
            }
            if (intent.hasExtra("id_niveau_choisi")){
                id_niveau_choisi = intent.getIntExtra("id_niveau_choisi",0);
            }
            if (intent.hasExtra("niveau")){
                niveau = intent.getStringExtra("niveau");
            }

        }


            webView=(WebView)findViewById(R.id.webView);

        webView.loadUrl("file:///android_asset/"+titre_cours+".html");
    }


}
