package com.example.easycode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class SuivanteActivity extends AppCompatActivity {

    String description="";
    String titre="";
    String image="";
    TextView des=null;
    TextView title=null;
    ImageView img=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suivante);
        Intent intent= getIntent();
        if(intent!=null){

            if (intent.hasExtra("description")){
                description= (intent.getStringExtra("description"));
            }
            if (intent.hasExtra("titre")){
                titre= (intent.getStringExtra("titre"));
            }
            if (intent.hasExtra("image")){
                image= (intent.getStringExtra("image"));
            }


        }
        des=findViewById(R.id.description);
        title=findViewById(R.id.titre);
        img=findViewById(R.id.img);

        des.setText(description);
        title.setText(titre);
        int imgid=getResources().getIdentifier(image,"drawable","com.example.easycode");
        img.setImageDrawable(getResources().getDrawable(imgid));


    }

}
